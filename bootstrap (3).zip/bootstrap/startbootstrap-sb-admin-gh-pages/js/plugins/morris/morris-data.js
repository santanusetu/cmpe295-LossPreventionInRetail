// Morris.js Charts sample data for SB Admin template

// Morris.js Charts sample data for SB Admin template

$(function() {
    
    // Area Chart
    Morris.Area({
        element: 'morris-area0-chart',
        data: [{
            period: '2010 Q1',
            theft: 2666,
            //rotten: null,
            //season: 2647
        }, {
            period: '2010 Q2',
            theft: 2778,
            //rotten: 2294,
            //season: 2441
        }, {
            period: '2010 Q3',
            theft: 4912,
            //rotten: 1969,
            //season: 2501
        }, {
            period: '2010 Q4',
            theft: 3767,
            //rotten: 3597,
            //season: 5689
        }, {
            period: '2011 Q1',
            theft: 6810,
            //rotten: 1914,
            //season: 2293
        }, {
            period: '2011 Q2',
            theft: 5670,
            //rotten: 4293,
            //season: 1881
        }, {
            period: '2011 Q3',
            theft: 4820,
            //rotten: 3795,
            //season: 1588
        }, {
            period: '2011 Q4',
            theft: 15073,
            //rotten: 5967,
            //season: 5175
        }, {
            period: '2012 Q1',
            theft: 10687,
            //rotten: 4460,
            //season: 2028
        }, {
            period: '2012 Q2',
            theft: 8432,
            //rotten: 5713,
            //season: 1791
        }],
        xkey: 'period',
        ykeys: ['theft'],
        labels: ['theft'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true
    });
//area1 Chart
Morris.Area({
        element: 'morris-area1-chart',
        data: [{
            period: '2010 Q1',
            //theft: 2666,
            rotten: null,
            //season: 2647
        }, {
            period: '2010 Q2',
            //theft: 2778,
            rotten: 2294,
            //season: 2441
        }, {
            period: '2010 Q3',
            //theft: 4912,
            rotten: 1969,
            //season: 2501
        }, {
            period: '2010 Q4',
            //theft: 3767,
            rotten: 3597,
            //season: 5689
        }, {
            period: '2011 Q1',
            //theft: 6810,
            rotten: 1914,
            //season: 2293
        }, {
            period: '2011 Q2',
            //theft: 5670,
            rotten: 4293,
            //season: 1881
        }, {
            period: '2011 Q3',
            //theft: 4820,
            rotten: 3795,
            //season: 1588
        }, {
            period: '2011 Q4',
            //theft: 15073,
            rotten: 5967,
            //season: 5175
        }, {
            period: '2012 Q1',
            //theft: 10687,
            rotten: 4460,
            //season: 2028
        }, {
            period: '2012 Q2',
           // theft: 8432,
            rotten: 5713,
            //season: 1791
        }],

        xkey: 'period',
        ykeys: [ 'rotten'],
        labels: ['rotten'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true
    });
//area2 chart
Morris.Area({
        element: 'morris-area2-chart',
        data: [{
            period: '2010 Q1',
            //theft: 2666,
            //rotten: null,
            season: 2647
        }, {
            period: '2010 Q2',
            //theft: 2778,
            //rotten: 2294,
            season: 2441
        }, {
            period: '2010 Q3',
            //theft: 4912,
            //rotten: 1969,
            season: 2501
        }, {
            period: '2010 Q4',
            //theft: 3767,
            //rotten: 3597,
            season: 5689
        }, {
            period: '2011 Q1',
            //theft: 6810,
            //rotten: 1914,
            season: 2293
        }, {
            period: '2011 Q2',
            //theft: 5670,
            //rotten: 4293,
            season: 1881
        }, {
            period: '2011 Q3',
            //theft: 4820,
            //rotten: 3795,
            season: 1588
        }, {
            period: '2011 Q4',
            //theft: 15073,
            //rotten: 5967,
            season: 5175
        }, {
            period: '2012 Q1',
            //theft: 10687,
            //rotten: 4460,
            season: 2028
        }, {
            period: '2012 Q2',
            //theft: 8432,
            //rotten: 5713,
            season: 1791
        }],
        xkey: 'period',
        ykeys: ['season'],
        labels: ['season'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true
    });


    // Donut Chart
    Morris.Donut({
        element: 'morris-donut-chart',
        data: [{
            label: "Theft",
            value: 90
        }, {
            label: "Rotten",
            value: 30
        }, {
            label: "Season",
            value: 20
        }],
        colors: [
    '#a6ff4d',
    '#bf4080',
    '#67C69D'
    ],
        resize: true
    });

    // Line Chart
    Morris.Line({
  element: 'morris-line-chart',
  lineColors: ["blue","red","green"],
  data: [
    { y: '2006', theft: 100, rotten: 90, season: 25 },
    { y: '2007', theft: 75,  rotten: 65, season: 32 },
    { y: '2008', theft: 50,  rotten: 40, season: 10  },
    { y: '2009', theft: 75,  rotten: 65, season: 29  },
    { y: '2010', theft: 50,  rotten: 40, season: 27 },
    { y: '2011', theft: 75,  rotten: 65, season: 16  },
    { y: '2012', theft: 100, rotten: 90, season: 13  }
  ],
  xkey: 'y',
  ykeys: ['theft', 'rotten', 'season'],
  labels: ['theft', 'rotten', 'season']
});
    // Bar Chart
    Morris.Bar({
  element: 'morris-bar-chart',
  barColors: ["#ff4000","orange","#d24dff"],
  data: [
    {x: '2011 Q1', theft: 3, rotten: 2, season: 3},
    {x: '2011 Q2', theft: 2, rotten: null, season: 1},
    {x: '2011 Q3', theft: 0, rotten: 2, season: 4},
    {x: '2011 Q4', theft: 2, rotten: 4, season: 3}
  ],
  xkey: 'x',
  ykeys: ['theft', 'rotten', 'season'],
  labels: ['Theft', 'Rotten', 'Season'],
  stacked: true
}).on('click', function(i, row){
  console.log(i, row);
});
    

});


/*
$(function() {
    
    // Area Chart
    Morris.Area({
        element: 'morris-area0-chart',
        data: [{
            period: '2010 Q1',
            theft: 2666,
            //rotten: null,
            //season: 2647
        }, {
            period: '2010 Q2',
            theft: 2778,
            //rotten: 2294,
            //season: 2441
        }, {
            period: '2010 Q3',
            theft: 4912,
            //rotten: 1969,
            //season: 2501
        }, {
            period: '2010 Q4',
            theft: 3767,
            //rotten: 3597,
            //season: 5689
        }, {
            period: '2011 Q1',
            theft: 6810,
            //rotten: 1914,
            //season: 2293
        }, {
            period: '2011 Q2',
            theft: 5670,
            //rotten: 4293,
            //season: 1881
        }, {
            period: '2011 Q3',
            theft: 4820,
            //rotten: 3795,
            //season: 1588
        }, {
            period: '2011 Q4',
            theft: 15073,
            //rotten: 5967,
            //season: 5175
        }, {
            period: '2012 Q1',
            theft: 10687,
            //rotten: 4460,
            //season: 2028
        }, {
            period: '2012 Q2',
            theft: 8432,
            //rotten: 5713,
            //season: 1791
        }],
        xkey: 'period',
        ykeys: ['theft'],
        labels: ['theft'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true
    });
//area1 Chart
Morris.Area({
        element: 'morris-area1-chart',
        data: [{
            period: '2010 Q1',
            //theft: 2666,
            rotten: null,
            //season: 2647
        }, {
            period: '2010 Q2',
            //theft: 2778,
            rotten: 2294,
            //season: 2441
        }, {
            period: '2010 Q3',
            //theft: 4912,
            rotten: 1969,
            //season: 2501
        }, {
            period: '2010 Q4',
            //theft: 3767,
            rotten: 3597,
            //season: 5689
        }, {
            period: '2011 Q1',
            //theft: 6810,
            rotten: 1914,
            //season: 2293
        }, {
            period: '2011 Q2',
            //theft: 5670,
            rotten: 4293,
            //season: 1881
        }, {
            period: '2011 Q3',
            //theft: 4820,
            rotten: 3795,
            //season: 1588
        }, {
            period: '2011 Q4',
            //theft: 15073,
            rotten: 5967,
            //season: 5175
        }, {
            period: '2012 Q1',
            //theft: 10687,
            rotten: 4460,
            //season: 2028
        }, {
            period: '2012 Q2',
           // theft: 8432,
            rotten: 5713,
            //season: 1791
        }],
        xkey: 'period',
        ykeys: [ 'rotten'],
        labels: ['rotten'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true
    });
//area2 chart
Morris.Area({
        element: 'morris-area2-chart',
        data: [{
            period: '2010 Q1',
            //theft: 2666,
            //rotten: null,
            season: 2647
        }, {
            period: '2010 Q2',
            //theft: 2778,
            //rotten: 2294,
            season: 2441
        }, {
            period: '2010 Q3',
            //theft: 4912,
            //rotten: 1969,
            season: 2501
        }, {
            period: '2010 Q4',
            //theft: 3767,
            //rotten: 3597,
            season: 5689
        }, {
            period: '2011 Q1',
            //theft: 6810,
            //rotten: 1914,
            season: 2293
        }, {
            period: '2011 Q2',
            //theft: 5670,
            //rotten: 4293,
            season: 1881
        }, {
            period: '2011 Q3',
            //theft: 4820,
            //rotten: 3795,
            season: 1588
        }, {
            period: '2011 Q4',
            //theft: 15073,
            //rotten: 5967,
            season: 5175
        }, {
            period: '2012 Q1',
            //theft: 10687,
            //rotten: 4460,
            season: 2028
        }, {
            period: '2012 Q2',
            //theft: 8432,
            //rotten: 5713,
            season: 1791
        }],
        xkey: 'period',
        ykeys: ['season'],
        labels: ['season'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true
    });


    // Donut Chart
    Morris.Donut({
        element: 'morris-donut-chart',
        data: [{
            label: "Theft",
            value: 90
        }, {
            label: "Rotten",
            value: 30
        }, {
            label: "Season",
            value: 20
        }],
        resize: true
    });

    // Line Chart
    Morris.Line({
  element: 'morris-line-chart',
  data: [
    { y: '2006', theft: 100, rotten: 90, season: 25 },
    { y: '2007', theft: 75,  rotten: 65, season: 32 },
    { y: '2008', theft: 50,  rotten: 40, season: 10  },
    { y: '2009', theft: 75,  rotten: 65, season: 29  },
    { y: '2010', theft: 50,  rotten: 40, season: 27 },
    { y: '2011', theft: 75,  rotten: 65, season: 16  },
    { y: '2012', theft: 100, rotten: 90, season: 13  }
  ],
  xkey: 'y',
  ykeys: ['theft', 'rotten', 'season'],
  labels: ['theft', 'rotten', 'season']
});
    // Bar Chart
    Morris.Bar({
  element: 'morris-bar-chart',
  data: [
    {x: '2011 Q1', theft: 3, rotten: 2, season: 3},
    {x: '2011 Q2', theft: 2, rotten: null, season: 1},
    {x: '2011 Q3', theft: 0, rotten: 2, season: 4},
    {x: '2011 Q4', theft: 2, rotten: 4, season: 3}
  ],
  xkey: 'x',
  ykeys: ['theft', 'rotten', 'season'],
  labels: ['Theft', 'Rotten', 'Season'],
  stacked: true
}).on('click', function(i, row){
  console.log(i, row);
});
    

});
*/